![Icon](https://github.com/EPOS05/MisakaRepoEPOS/blob/main/Images/Repo/EPOSbox_128x128.png?raw=true)
# EPOSbox
The MDC repo for you

## misaka
Download the misaka public beta now on the misakaTeam [Discord server](https://discord.gg/SDenpXk9C2)

## Repo
You can add my repo using the following URL: https://raw.githubusercontent.com/EPOS05/MisakaRepoEPOS/main/repo.json
